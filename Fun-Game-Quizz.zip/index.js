//Fun game quiz
var readlineSync = require('readline-sync');

const chalk = require('chalk');

console.log(chalk.blue("Welcome To Take This Quiz.\n"));

	 var highScores = [{
			name: "Sana ",
  		score: 5 
   },
   {
      name: "Shahid",
      score: 4
}]

var score = 0;
var userName = readlineSync.question("Please Enter your name ? ");



console.log(chalk.red("\nRules"+"\n1. There are 10 question in all ,one point per question \n2. Negative marking for each wrong answer\n3. Choose answer from the given option\n"));

console.log('Welcome ' + userName + ' Good Luck ');

function play(question,answer) {
  var userAnswer=readlineSync.question("\n"+question+"\n");


 if (userAnswer === answer) 
 {
    console.log(chalk.green("Right Answer"));
    score = score + 1;
    
  } else {
    console.log(chalk.red("Wrong Answer"));
    score = score -1;
   
  }
  
  console.log(".......................................")
  console.log(userName + " Your Current Score is : ", score);
}


var questions = [{
question: ("1. What Indian city is the capital of two states ? ")+("\na. Mumbai\nb. Chandigarh\nc. Kolkata\nd. Chennai"),
answer: "b"
},
{
  question: ("2. How many countries border India ?")+("\na. 4  \nb. 8 \nc. 14  \nd. 6 "),
  answer:"d"
},
{
  question: ("3. What is the capital of Gujarat ?")+(" \na. Gandhinagar  \nb. Mumbai \nc. Lucknow  \nd. Banglore"),
  answer:"a"
},
{
  question: ("4. Who was the president of India in 2009 ? ")+("\na. Pratibha Patil  \nb. Govind Singh  \nc. Indira Gandhi \nd. Smriti Irani"),
  answer:"a"
},
{
  question: ("5. What is India’s smallest state by area ? ")+ ("\na. Kerala\nb. Goa \nc. Assam \nd. West Bengal"),
  answer:"b"
},
{
  question:("6. What is the official language in India ? ")+ ("\na. Kokni\nb. There is no official language \nc. Kannada \nd. Hindi"),
  answer:"b"
},
{
  question:("7. Which two cities in India are on the UNESCO World Heritage list ? ")+ ("\na. Jaipur and Ahmedabad \nb. Kolkata and Udaipur \nc. Mysore and Delhi \nd. Agra and Lucknow"),
  answer:"a"
},
{
  question:("8. The Madhubani style of painting is practiced in which state in India ? ")+ ("\na. Rajasthan\nb. Karnataka \nc. Bihar \nd. Delhi"),
  answer:"c"
},
{
  question:("9. Which one of these novel is written by Khushwant Singh ? ")+ ("\na. Untouchable\nb. A Suitable Boy\nc. Fire on the mountain \nd. Train to pakistan"),
  answer:"d"
},
{
  question:("10. True Or False: Swami Vivekananda said, We are what our thoughts have made us; so take care about what you think. Words are secondary. Thoughts live; they travel far. ")+ ("\na. True\nb. False"),
  answer:"a"
}];

for (var i=0; i<questions.length; i++) {
  var currentQuestion = questions[i];
  play(currentQuestion.question,currentQuestion.answer)
}


console.log("\n" +userName+"  Your Final Score is " + score);


console.log("\nCurrent Highscores Are");
		for (i = 0; i <highScores.length; i++) {
			console.log((i + 1) + " " + highScores[i].name + ": " + highScores[i].score);
		}


console.log("\nIf you beat the highScores take a screenshot and message me ");
console.log("\n**** Thank You For Playing  ****");
